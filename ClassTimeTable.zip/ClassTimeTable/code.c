#include <stdio.h>
#include <string.h>

void Allot_Lab(int noclasses,int p,int lcount[],int lh[][2],int lfac[][2],int lfac2[][2],int slots[][30],int FA[][30],int lrooms[][30],int lcrooms[][2],int labcourses[]);
void Allot_Theory(int noclasses,int p,int fcount[],int fh[][3],int slots[][30],int fcourses[],int courses[],int FA[][30],int count[],int fac[][6],int h[][6]);
void ClassFile(FILE *fptr,int rec,int p,char per[][5],char day[],char week[][4],char subjects[][12][4],char periods[][6][4],char classes[][5],int slots[][30]);
void LabFile(FILE *fptr,int p,char per[][5],char day[],char week[][4],char classes[][5],int lrooms[][30]);
void FacultyFile(FILE *fptr,int p,char per[][5],char day[],char week[][4],char periods[][6][4],int FA[][30],char classes[][5]);

int main()
{ 
    FILE *fptr;
    int noclasses;
    printf("Enter the number of classes:");
    scanf("%d",&noclasses);
    int days = 5;
    int p;
    printf("Enter the periods in a day:");
    scanf("%d",&p);
    int N = 30;
    int nlabs = 6;
    char breaks[2][6];
    strcpy(breaks[0],"BREAK\0");
    strcpy(breaks[1],"LUNCH\0");
    int FA[50][30]={{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                   {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
    int lrooms[6][30] ={{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
    int courses[6]={1,2,3,4,5,6};
    int labcourses[2] = {7,8};
    int lcount[8] = {2,2,2,2,2,2,2,2};
    int lfac[8][2] ={{2,3},{8,9},{12,13},{42,40},{18,19},{23,44},{29,30},{45,47}};
    int lfac2[8][2] = {{38,39},{39,38},{40,41},{13,14},{40,43},{24,45},{44,45},{46,48}};
    int lcrooms[8][2] = {{0,1},{0,2},{0,1},{0,3},{4,4},{4,2},{4,3},{4,5}};
    int lh[8][2]={{2,2},{2,2},{2,2},{2,2},{2,2},{2,2},{2,2},{2,2}};
    int labno;
    int fcourses[3] = {9,10,11};
    int fh[8][3] = {{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1}};
    int slots[8][30]={{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
    int h[8][6]={{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},
                {5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2}};
    int count[8] = {22,22,22,22,22,22,22,22};
    int fcount[8] = {4,4,4,4,4,4,4,4};
    if (p == 5){
    int ph[8][6]={{4,3,3,3,3,2},{4,3,3,3,3,2},{4,3,3,3,3,2},{4,3,3,3,3,2},
                {4,3,3,3,3,2},{4,3,3,3,3,2},{4,3,3,3,3,2},{4,3,3,3,3,2}};
    int pcount[8] = {18,18,18,18,18,18,18,18};
    int pfh[8][3] = {{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1}};
    int pfcount[8] = {3,3,3,3,3,3,3,3};
    memcpy(&h,&ph,sizeof(h));
    memcpy(&count,&pcount,sizeof(count));
    memcpy(&fh,&pfh,sizeof(fh));
    memcpy(&fcount,&pfcount,sizeof(fcount));
                }
    else if (p == 6){
    int ph[8][6]={{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},
                {5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2},{5,4,3,4,4,2}};
    int pcount[8] = {22,22,22,22,22,22,22,22};
    int pfh[8][3] = {{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1},{1,2,1}};
    int pfcount[8] = {4,4,4,4,4,4,4,4};
    memcpy(&h,&ph,sizeof(h));
    memcpy(&count,&pcount,sizeof(count));
    memcpy(&fh,&pfh,sizeof(fh));
    memcpy(&fcount,&pfcount,sizeof(fcount));
                }
    else if (p == 4){
    int ph[8][6]={{3,2,2,2,2,2},{3,2,2,2,2,2},{3,2,2,2,2,2},{3,2,2,2,2,2},
                {3,2,2,2,2,2},{3,2,2,2,2,2},{3,2,2,2,2,2},{3,2,2,2,2,2}};
    int pcount[8] = {13,13,13,13,13,13,13,13};
    int pfh[8][3] = {{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1}};
    int pfcount[8] = {3,3,3,3,3,3,3,3};
    memcpy(&h,&ph,sizeof(h));
    memcpy(&count,&pcount,sizeof(count));
    memcpy(&fh,&pfh,sizeof(fh));
    memcpy(&fcount,&pfcount,sizeof(fcount));
                }
    
    int fac[8][6]={{1,2,3,4,5,6},{7,8,9,10,5,6},{11,12,13,14,15,16},{12,13,14,11,15,16},{17,18,19,20,21,16},{22,23,24,25,26,27},{28,29,30,31,32,27},{33,34,35,36,37,6}};
    
    char subjects[8][12][4]={{"---\0","MAT\0","C++\0","FDS\0","PYT\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","C++\0","FDS\0","PYT\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","PYT\0","NET\0","PHY\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","PYT\0","NET\0","PHY\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","CIR\0","MEC\0","EEE\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","BIO\0","CHE\0","MED\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","INS\0","MEC\0","ECE\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"},
                            {"---\0","MAT\0","CHE\0","NAN\0","PHY\0","ENG\0","EVS\0","L-1\0","L-2\0","Lib\0","Men\0","Spo\0"}};
    char periods[5][6][4] = {{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""}};
    int a,i,j,k,l,m,x,y,z,yes,t;
    char week[5][4] = {"MON\0","TUE\0","WED\0","THU\0","FRI\0"};
    char per[7][5] = {"Day\0","I\0","II\0","III\0","IV\0","V\0","VI\0"};
    char classes[9][5] = {"---\0","CSEA\0","CSEB\0","ITA\0","ITB\0","EEEA\0","BMEB\0","ECEA\0","CHEM\0"};
    char day[3];
    int flag = 0;
    int facno;
    char ch;
    for (a=0; a < noclasses; a++){
        
        int sum = 0;
        int l1 = sizeof(h[a])/sizeof(h[a][0]);
        int l2 = sizeof(lh[a])/sizeof(lh[a][0]);
        int l3 = sizeof(fh[a])/sizeof(fh[a][0]); 
        for (int i = 0; i < l1; i++) {     
        sum = sum + h[a][i];
        } 
        for (int i = 0; i < l2; i++) {     
        sum = sum + lh[a][i];  
        }  
        for (int i = 0; i < l3; i++) {     
        sum = sum + fh[a][i];
        }
        if (sum > (days * p)){
            printf("The hours given for the class-%s has exceeded the limit.\n",classes[a+1]);
            flag = 1;
        }       
    }
    if (flag != 1){
    Allot_Lab(noclasses,p,lcount,lh,lfac,lfac2,slots,FA,lrooms,lcrooms,labcourses);
    Allot_Theory(noclasses,p, fcount,fh,slots,fcourses,courses,FA,count,fac, h);
        printf("------------------------------------------------------\n");
        printf("\t\t Class Timetables:");
        printf("\n------------------------------------------------------\n");
        fptr=fopen("Classes.txt","w");
        for(a = 0; a < noclasses;a++){
        printf("***************************************************************\n");
        printf("The required timetable for the given class-%s :\n\n",classes[a+1]);
        for (x = 0; x < p + 1; x++){
            if (p==6 && x==3) printf("\t");
            else if (p==6 && x==5) printf("\t");
            else if (p==5 && x==4) printf("\t");
            else if (p==4 && x==3) printf("\t");
            if (x != p){
                printf("%s\t",per[x]);
            }
            else{
                printf("%s\n",per[x]);
            }
        }
        m = 0;
        for (j=0;j<days;j++){
            printf("\n");
            strcpy(day,week[j]);
            printf("%s\t",day);
            for (k=0;k<p;k++){
            if (p==6 && k==2) printf("%c\t",breaks[0][j]);
            else if (p==6 && k==4) printf("%c\t",breaks[1][j]);
            else if (p==5 && k==3) printf("%c\t",breaks[1][j]);
            else if (p==4 && k==2) printf("%c\t",breaks[1][j]);
            l = slots[a][m];
            strcpy(periods[j][k],subjects[a][l]);
            if (k == p-1){
                printf("%s\n",periods[j][k]);
            }
            else{
            printf("%s\t",periods[j][k]);}
            m++;
            }
            }printf("\n");
            ClassFile(fptr,a,p,per,day,week,subjects,periods,classes,slots);
        }
        fclose(fptr);
        fptr=fopen("Lab.txt","w");
        printf("\n------------------------------------------------------\n");
        printf("\t\t Lab Timetables:");
        printf("\n------------------------------------------------------\n");
        for (a = 0; a < nlabs; a++){
            printf("***********************************************************\n");
        printf("The required timetable for the given Lab-%d :\n\n",a+1);
        for (x = 0; x < p + 1; x++){
            if (x != p){
                printf("%s\t",per[x]);
            }
            else{
                printf("%s\n",per[x]);
            }
        }
        char lperiods[5][6][4] = {{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""}};
        m = 0;
        for (j=0;j<days;j++){
            printf("\n");
            strcpy(day,week[j]);
            printf("%s\t",day);
            for (k=0;k<p;k++){
            l = lrooms[a][m];
            strcpy(lperiods[j][k],classes[l]);
            if (k == p-1){
                printf("%s\n",lperiods[j][k]);
            }
            else{
            printf("%s\t",lperiods[j][k]);}
            m++;
            }
            }printf("\n");
        }
        LabFile(fptr,p,per,day,week,classes,lrooms);
        fclose(fptr);
        fptr=fopen("Faculties.txt","w");
        FacultyFile(fptr,p,per,day,week,periods,FA,classes);
        fclose(fptr);
        printf("\n------------------------------------------------------\n");
        printf("\t\t Faculty Timetables:");
        printf("\n------------------------------------------------------\n");
        do{
            printf("Enter the number of the faculty:");
            scanf("%d",&facno);
            printf("\nThe required timetable for the given faculty-%d :\n",facno);
            for (x = 0; x < p + 1; x++){
            if (x != p){
                printf("%s\t",per[x]);
            }
            else{
                printf("%s\n",per[x]);
                }
            }
            m = 0;
            for (j=0;j<days;j++){
                printf("\n");
                strcpy(day,week[j]);
                printf("%s\t",day);
                for (k=0;k<p;k++){
                l = FA[facno][m];
                strcpy(periods[j][k],classes[l]);
                if (k == p-1){
                    printf("%s\n",periods[j][k]);
                }
                else{
                printf("%s\t",periods[j][k]);}
                m++;
                    }
                }
            printf("Do you want to see another faculty's timetable?(y/n)");
            scanf(" %c",&ch);

            }while (ch != 'n');
            flag = 1;
        }
        return 0;
    }

void Allot_Lab(int noclasses,int p,int lcount[],int lh[][2],int lfac[][2],int lfac2[][2],int slots[][30],int FA[][30],int lrooms[][30],int lcrooms[][2],int labcourses[])
{
    int a=0,i=0,j=0,k=0,t=0,labno=0,N=30;
    for (a=0; a < noclasses; a++){
        while (lcount[a] > 0){
        for (i = 0; i < 2; i++){
            if (lh[a][i] < 1){
                continue;
            }
            else{
                if ((a+1)%2==0){
                    j = p-2+p;
                }
                else{
                j = p-2;
                }
                while (j < N){
                    k = lfac[a][i];
                    t = lfac2[a][i];
                    if (slots[a][j]==0){
                        labno = lcrooms[a][i];
                        if (FA[k][j] == 0 && FA[k][j+1] ==0 && lrooms[labno][j] == 0){
                            slots[a][j] = labcourses[i];
                            FA[k][j] = a+1;
                            FA[t][j] = a+1;
                            slots[a][j+1] = labcourses[i];
                            FA[k][j+1] = a+1;
                            FA[t][j+1] = a+1;
                            lrooms[labno][j] = a+1;
                            lrooms[labno][j+1] = a+1;
                            lh[a][i] -= 1;
                            lcount[a] -= 1;FA[k][j] = a+1;
                            break;
                        }
                    }
                    j+=(2*p);
                }

            }
        }
        }
        }
}

void Allot_Theory(int noclasses,int p,int fcount[],int fh[][3],int slots[][30],int fcourses[],int courses[],int FA[][30],int count[],int fac[][6],int h[][6])
{
    int i=0,j=0,k=0,N=30,a=0;
    for (a=0; a< noclasses; a++){
        while (fcount[a] > 0){
            for (i = 0; i < 3; i++){
                if (fh[a][i] < 1){
                    continue;
                }
                else{
                    j = p-1;
                    while (j < N){
                        if (fh[a][i] == 2){
                            if (slots[a][j]==0){
                                    slots[a][j] = fcourses[i];
                                    slots[a][j-1] = fcourses[i];
                                    fh[a][i] -= 2;
                                    fcount[a] -= 2;
                                    break;
                                }
                        }
                        else{
                            if (slots[a][j]==0){
                                    slots[a][j] = fcourses[i];
                                    fh[a][i] -= 1;
                                    fcount[a] -= 1;
                                    break;
                                }
                            }
                            j+=p;
                        }
                    }
                }
            }
        }
    for(a = 0; a < noclasses;a++){
        while (count[a] > 0){
        for (i = 0; i < 6; i++){
            if (h[a][i] < 1){
                continue;
            }
            else{
                j = 0;
                while (j < N){
                    k = fac[a][i];
                    if (slots[a][j]==0){
                        if (FA[k][j] < 1){
                            slots[a][j] = courses[i];
                            FA[k][j] = a+1;
                            h[a][i] -= 1;
                            count[a] -= 1;
                            break;
                        }
                    }
                    j++;
                }

            }
        }
        }
    }
}

void ClassFile(FILE *fptr,int rec,int p,char per[][5],char day[],char week[][4],char subjects[][12][4],char periods[][6][4],char classes[][5],int slots[][30])
{
    int x=0,j=0,m=0,l=0,k=0,days=5;
    char breaks[2][6];
    strcpy(breaks[0],"BREAK\0");
    strcpy(breaks[1],"LUNCH\0");
    fprintf(fptr,"***************************************************************\n");
    fprintf(fptr,"%s %s\n","CLASS :",classes[rec+1]);
        for (x = 0; x < p + 1; x++){
            if (p==6 && x==3) fprintf(fptr,"\t");
            else if (p==6 && x==5) fprintf(fptr,"\t");
            else if (p==5 && x==4) fprintf(fptr,"\t");
            else if (p==4 && x==3) fprintf(fptr,"\t");
            if (x != p){
                fprintf(fptr,"%s\t",per[x]);
            }
            else{
                fprintf(fptr,"%s\n",per[x]);
            }
        }
        m = 0;
        for (j=0;j<days;j++){
            strcpy(day,week[j]);
            fprintf(fptr,"%s\t",day);
            for (k=0;k<p;k++){
            l = slots[rec][m];
            strcpy(periods[j][k],subjects[rec][l]);
            if (p==6 && k==2) fprintf(fptr,"%c\t",breaks[0][j]);
            else if (p==6 && k==4) fprintf(fptr,"%c\t",breaks[1][j]);
            else if (p==5 && k==3) fprintf(fptr,"%c\t",breaks[1][j]);
            else if (p==4 && k==2) fprintf(fptr,"%c\t",breaks[1][j]);
            if (k == p-1){
                fprintf(fptr,"%s\n",periods[j][k]);
            }
            else{
            fprintf(fptr,"%s\t",periods[j][k]);}
            m++;
            }
            }fprintf(fptr,"\n");
}


void LabFile(FILE *fptr,int p,char per[][5],char day[],char week[][4],char classes[][5],int lrooms[][30])
{
    int a=0,m=0,x=0,days=5,l=0,k=0,j=0,nlabs=6;
    for (a = 0; a < nlabs; a++){
        fprintf(fptr,"*****************************************************\n");
        fprintf(fptr,"%s %d:\n","LAB -",a+1);
        for (x = 0; x < p + 1; x++){
            if (x != p){
                fprintf(fptr,"%s\t",per[x]);
            }
            else{
                fprintf(fptr,"%s\n",per[x]);
            }
        }
        char lperiods[5][6][4] = {{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""},{"","","","","",""}};
        m = 0;
        for (j=0;j<days;j++){
            strcpy(day,week[j]);
            fprintf(fptr,"%s\t",day);
            for (k=0;k<p;k++){
            l = lrooms[a][m];
            strcpy(lperiods[j][k],classes[l]);
            if (k == p-1){
                fprintf(fptr,"%s\n",lperiods[j][k]);
            }
            else{
            fprintf(fptr,"%s\t",lperiods[j][k]);}
            m++;
            }
            }fprintf(fptr,"\n");
        }
}

void FacultyFile(FILE *fptr,int p,char per[][5],char day[],char week[][4],char periods[][6][4],int FA[][30],char classes[][5])
{
    int i=0,l=0,x=0,days=5,j=0,m=0,k=0;
    for(i=1;i<=48;i++)
    {
        fprintf(fptr,"******************************************\n");
        fprintf(fptr,"%s %d:\n","FACULTY-",i);
        for (x = 0; x < p + 1; x++)
        {
            if (x != p)
            {
                fprintf(fptr,"%s\t",per[x]);
            }
            else
            {
                fprintf(fptr,"%s\n",per[x]);
            }
        }
        m = 0;
        for (j=0;j<days;j++)
        {
            strcpy(day,week[j]);
            fprintf(fptr,"%s\t",day);
	    
            for (k=0;k<p;k++)
            {
                l = FA[i][m];
                strcpy(periods[j][k],classes[l]);
                if (k == p-1)
                {
                    fprintf(fptr,"%s\n",periods[j][k]);
                }
                else
                {
                    fprintf(fptr,"%s\t",periods[j][k]);
                }
                m++;
            }
        }
    }
    fclose(fptr);
}